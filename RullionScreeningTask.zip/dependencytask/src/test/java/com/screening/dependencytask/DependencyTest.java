package com.screening.dependencytask;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import com.screening.exception.CyclicException;


public class DependencyTest {
	
	Task task ;
	
	 @Before
	  public void setUp() {
	    task = new Task();
	  }

	  @Test
	  public void dependencyTest1() {
		  List<String> result =
	    		task.findDependency("", "");
	    assertEquals("[]", result.toString());
	  }

	  @Test
	  public void dependencyTest2() {
		  List<String> result =
		    		task.findDependency("a,b", "");
	    assertEquals("[a, b]", result.toString());
	  }

	  @Test
	  public void dependencyTest3() {
		  List<String> result =
		    		task.findDependency("a,b", "a=>b");
	    assertEquals("[b, a]", result.toString());
	  }

	  @Test
	  public void dependencyTest4() {
		  List<String> result =
		    		task.findDependency("a,b,c,d", "a=>b,c=>d");
	    assertEquals("[b, a, d, c]", result.toString());
	  }

	  @Test
	  public void dependencyTest5() {
		  List<String> result =
		    		task.findDependency("a,b,c", "a=>b,b=>c");
	    assertEquals("[c, b, a]", result.toString());
	  }

	  @Test(expected = CyclicException.class)
	  public void dependencyTest6() {
		    task.findDependency("a,b,c,d","a=>b,b=>c, c=>a");
	  }

}
