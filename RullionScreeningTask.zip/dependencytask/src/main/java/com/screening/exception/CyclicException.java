package com.screening.exception;

public class CyclicException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	  public CyclicException(String msg) {
	    super(msg);
	  }
}
