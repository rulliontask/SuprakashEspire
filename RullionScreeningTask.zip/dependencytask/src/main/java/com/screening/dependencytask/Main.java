package com.screening.dependencytask;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;
import com.screening.exception.CyclicException;

public class Main {

	Task task = new Task();

	public static void main(String[] args) {
		Main taskMain = new Main();
		// taskMain.ReadFromInputFile();

		taskMain.readFromConsole();
	}

	private void readFromConsole() {
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter Tasks in the form a,b,c,d followed by newline   : ");
			String tasks = sc.nextLine();

			System.out.println("Enter Dependencies in the form a=>b,c=>d,a=>d followed by newline  : ");
			String dependency = sc.nextLine();

			System.out.println("\ntasks: [" + tasks + "]");
			System.out.println("dependencies: [" + dependency + "]");

			List<String> result = null;
			try {
				result = task.findDependency(tasks, dependency);
				System.out.println("result: " + result);
			} catch (Exception e) {
				System.out.println(e.getMessage()) ;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void readFromInputFile() {
		Scanner sc = null;
		try {
			sc = new Scanner(new File(".\\src\\main\\java\\com\\screening\\dependencytask\\input.txt"));
		} catch (FileNotFoundException e) {
			System.out.println("Invalid file path");
			return;
		}

		Integer testCount = Integer.parseInt(sc.nextLine());
		for (int tc = 0; tc < testCount; tc++) {

			String tasks = sc.nextLine();
			String dependency = sc.nextLine();
			System.out.println("\ntasks: [" + tasks + "]");
			System.out.println("dependencies: [" + dependency + "]");

			List<String> result = null;
			try {
				result = task.findDependency(tasks, dependency);
			} catch (CyclicException e) {
				System.out.println("result: Error - this is a cyclic dependency");
				continue;
			}

			System.out.println("result: " + result);
		}
	}
}
