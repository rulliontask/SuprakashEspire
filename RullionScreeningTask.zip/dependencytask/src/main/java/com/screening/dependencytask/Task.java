package com.screening.dependencytask;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import com.screening.exception.CyclicException;

public class Task {
	
	public List<String> findDependency(String tasks, String dependency) {
		
		List<String> result = new ArrayList<>();
		Optional<Entry<String, Integer>> noDep;
		
		/* Arrange the tasks in a map of task <=> inCount map.
		 * inCount is the number of directed edges into the task.Just initialized to 0 here.
		 * So, InCount will give the number of dependencies of a task.
		 * tasks will be arranged in order of read from  input.
		 * */
		LinkedHashMap<String, Integer> inCountMap = Arrays.asList(tasks.split(",")).stream()
				.collect(Collectors.toMap(e -> e, e -> 0, (e1, e2) -> e1, LinkedHashMap::new));
		
		/* Arranges dependencies in a list of task(e[0]) and its dependency (e[1]).
		 * e[0] => task , e[1] => task on which e[0] is dependent
		 */
		List<String[]> dependencyList = Arrays.asList(dependency.split(",")).stream().map(e -> e.split("=>"))
				.filter(e -> !e[0].isBlank() && !e[1].isBlank())
				.map(e ->  new String[]{ e[0].strip(), e[1].strip()}).collect(Collectors.toList());
		
		/* Converts the dependency list into a dependency map
		 * where key of dependency map is the task and value is a set of tasks which are dependent on the key 
		 */
		Map<String, Set<String>> dependencyMap = getDependencyMap(dependencyList);
		
		
		/* InCount of a task(e) is the count of the number of tasks on which e is dependent
		 * This function will store the task and its corresponding inCount in a map 
		 * It uses the dependency map
		 */	
		initializeInCountMap(inCountMap, dependencyMap);
		
		do {
			/*Find the first task(T) with inCount as 0. 
			 * So this task(T) will have no dependency and so it can be added to the result list.
			 * As T is already added to the result list means it will be processed first. So as it is already being 
			 * processed, so all tasks dependent on this task will have their inCount i.e dependency count reduced by 1
			 * Remove this task from inCount map also as it has no dependency
			 * Remove task from dependency map as after being added to result list all dependent tasks are satisfied.
			 */
			noDep = inCountMap.entrySet().stream().filter(e -> e.getValue() == 0).findFirst();
			noDep.ifPresentOrElse(e -> {
				result.add(e.getKey());
				inCountMap.remove(e.getKey());
				if (dependencyMap.get(e.getKey()) != null) {
					dependencyMap.get(e.getKey()).forEach(dep -> {
						inCountMap.put(dep, inCountMap.get(dep) - 1);
					});
				}
				dependencyMap.remove(e.getKey());
			} , () -> {
				/* If all tasks have dependencies(InCount > 0) i.e all are dependent on each other 
				 * It means there is a cycle.
				 */
				if(inCountMap.size() > 1) {
					throw new CyclicException("Error - this is a cyclic dependency");
				}
			});
			
		} while (!noDep.isEmpty());

		return result;

	}

	
	private Map<String, Set<String>> getDependencyMap(List<String[]> dependencies) {
		Map<String, Set<String>> dependencyMap = new HashMap<>();
		dependencies.forEach(e -> {
			dependencyMap.putIfAbsent(e[1], new HashSet<String>());
			dependencyMap.get(e[1]).add(e[0]);
		});
		return dependencyMap;
	}
	
	private void initializeInCountMap(LinkedHashMap<String, Integer> inCountMap,
			Map<String, Set<String>> dependencyMap) {
		dependencyMap.values().forEach(dset -> {
			dset.forEach(e -> inCountMap.put(e, inCountMap.get(e) + 1));
		});
	}

}
